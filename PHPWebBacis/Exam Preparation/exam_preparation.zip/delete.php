<?php

require_once "common.php";

$itemHttpHandler->delete($_GET);