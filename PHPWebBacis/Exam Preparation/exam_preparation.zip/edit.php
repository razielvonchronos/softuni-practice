<?php

require_once "common.php";

$itemHttpHandler->edit($_POST);