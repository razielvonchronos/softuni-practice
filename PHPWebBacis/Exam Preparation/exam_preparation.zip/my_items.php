<?php

require_once "common.php";

$itemHttpHandler->myItems();