<?php

require_once "common.php";

$userHttpHandler->login($_POST);