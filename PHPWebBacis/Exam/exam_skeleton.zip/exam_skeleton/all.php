<?php

require_once "common.php";

$userHttpHandler->all($userService);