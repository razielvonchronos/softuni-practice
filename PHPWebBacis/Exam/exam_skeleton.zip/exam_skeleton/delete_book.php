<?php

require_once "common.php";

$bookHttpHandler->delete($_GET);