<?php

require_once "common.php";

$bookHttpHandler->allBooksByAuthor();