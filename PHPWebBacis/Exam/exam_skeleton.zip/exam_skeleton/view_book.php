<?php

require_once "common.php";

$bookHttpHandler->view($_GET);