<?php

require_once "common.php";

$userHttpHandler->myProfile($_POST);